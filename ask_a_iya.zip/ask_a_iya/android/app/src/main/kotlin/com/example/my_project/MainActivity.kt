package com.company.flutterai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
