import '/flutter_flow/flutter_flow_util.dart';
import 'nointernet_widget.dart' show NointernetWidget;
import 'package:flutter/material.dart';

class NointernetModel extends FlutterFlowModel<NointernetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
